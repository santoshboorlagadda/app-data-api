import { useState, useEffect, useCallback } from "react";
import {
  Boxes, LayoutGrid, PlayCircle, RefreshCw, Rocket, Check, X,
  AlertCircle, Loader2, ArrowUpCircle, ShieldCheck, GitBranch,
} from "lucide-react";

const API = "http://localhost:8000";

const TYPE_CHIP = {
  ".NET": "bg-violet-100 text-violet-700", React: "bg-sky-100 text-sky-700",
  Node: "bg-emerald-100 text-emerald-700", Java: "bg-orange-100 text-orange-700",
  unknown: "bg-slate-100 text-slate-500",
};
const TERMINAL = ["completed", "failed", "jenkins_failed", "timeout"];
const CELL = {
  SUCCESS: "bg-emerald-500", IN_PROGRESS: "bg-indigo-500 animate-pulse",
  FAILED: "bg-rose-500", NOT_EXECUTED: "bg-slate-200",
};

function _sameVer(current, target) {
  if (!current) return false;
  const nums = String(current).match(/\d+(\.\d+)?/g) || [];
  const t = String(target).split(".")[0];
  return nums.some(n => n.split(".")[0] === t);
}

const api = {
  apps: () => fetch(`${API}/api/apps`).then(r => r.json()),
  register: b => fetch(`${API}/api/apps`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(b) }).then(r => r.json()),
  del: id => fetch(`${API}/api/apps/${id}`, { method: "DELETE" }).then(r => r.json()),
  upgrade: app_id => fetch(`${API}/api/upgrades`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ app_id }) }).then(r => r.json()),
  rebuild: app_id => fetch(`${API}/api/rebuilds`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ app_id }) }).then(r => r.json()),
  catalog: () => fetch(`${API}/api/catalog`).then(r => r.json()),
  bulkUpgrade: (type, target_version) => fetch(`${API}/api/upgrades/bulk`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, target_version }) }).then(r => r.json()),
  runAllByType: (type, target_version) => fetch(`${API}/api/jenkins/run-all`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, target_version }) }).then(r => r.json()),
  rebuildAll: (runtime) => fetch(`${API}/api/rebuilds/all${runtime ? `?runtime=${runtime}` : ""}`, { method: "POST" }).then(r => r.json()),
  trigger: app_id => fetch(`${API}/api/jenkins/trigger`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ app_id }) }).then(r => r.json()),
  jobs: () => fetch(`${API}/api/jobs`).then(r => r.json()),
  approve: id => fetch(`${API}/api/upgrades/${id}/approve`, { method: "POST" }).then(r => r.json()),
  reject: id => fetch(`${API}/api/upgrades/${id}/reject`, { method: "POST" }).then(r => r.json()),
};

const inputCls = "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100";

function Field({ label, children }) {
  return <label className="block"><span className="mb-1 block text-sm font-medium text-slate-700">{label}</span>{children}</label>;
}

// ── Tab 1: Register + analyze ─────────────────────────────────────────────────
function Register({ onDone, types }) {
  const empty = { name: "", type: "", repo_url: "", branch: "main", jenkins_job: "", config_repo_url: "", cluster: "", namespace: "", deployment: "", app_prefix: "" };
  const [f, setF] = useState(empty);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const set = k => e => setF(p => ({ ...p, [k]: e.target.value }));
  const F = ({ label, k, mono }) => <Field label={label}><input className={`${inputCls} ${mono ? "font-mono" : ""}`} value={f[k]} onChange={set(k)} /></Field>;

  async function save() {
    if (!f.name || !f.type || !f.repo_url || !f.jenkins_job) { setMsg({ err: true, t: "Name, type, repo, and Jenkins job are required." }); return; }
    setBusy(true);
    const a = await api.register(f);
    setBusy(false);
    if (a.detail) { setMsg({ err: true, t: a.detail }); return; }        // duplicate repo
    setMsg(a.analyze_error ? { err: true, t: `Saved, but detection failed: ${a.analyze_error}` }
      : { err: false, t: `Registered ${a.name} — detected current version: ${a.current_version}` });
    setF(empty); onDone();
  }

  return (
    <div className="grid gap-4">
      <section className="grid gap-4 rounded-xl border border-slate-200 bg-white p-5 sm:grid-cols-2">
        <F label="Application name" k="name" mono />
        <Field label="Type">
          <select className={inputCls} value={f.type} onChange={set("type")}>
            <option value="">select…</option>
            {types.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </Field>
        <F label="Git repository" k="repo_url" mono />
        <F label="Branch" k="branch" mono />
        <F label="Jenkins pipeline (job name)" k="jenkins_job" mono />
        <F label="Config repo (EKS details)" k="config_repo_url" mono />
        <F label="EKS cluster (QA)" k="cluster" mono />
        <F label="Namespace" k="namespace" mono />
        <F label="Deployment" k="deployment" mono />
        <F label="Image prefix to strip" k="app_prefix" mono />
      </section>
      <p className="text-xs text-slate-400">On save, the agent clones the repo and analyzes type + current version, and checks whether a newer version is available.</p>
      {msg && <div className={`flex items-center gap-2 rounded-lg px-4 py-3 text-sm ${msg.err ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-800"}`}>{msg.err ? <AlertCircle size={16} /> : <Check size={16} />} {msg.t}</div>}
      <div className="flex justify-end">
        <button onClick={save} disabled={busy} className="flex items-center gap-2 rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-60">
          {busy ? <Loader2 size={16} className="animate-spin" /> : <Boxes size={16} />} Save & analyze
        </button>
      </div>
    </div>
  );
}

// ── Job status card (used under an app) ───────────────────────────────────────
function JobCard({ job, reload }) {
  const cols = Array.from((job.stages || []).reduce((s, x) => s.add(x.name), new Set()));
  return (
    <div className="mt-2 rounded-lg border border-slate-200 bg-slate-50 p-3">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium text-slate-700">{job.kind} · <span className="font-mono">{job.state}</span>{job.git_tag ? ` · tag ${job.git_tag}` : ""}{job.work_branch ? ` · ${job.work_branch}` : ""}</span>
        {job.error && <span className="text-rose-600">{job.error}</span>}
      </div>

      {job.state === "awaiting_approval" && job.pending_fix && (
        <div className="mt-2 rounded-md border border-amber-300 bg-amber-50 p-3">
          <div className="mb-1 text-xs font-semibold text-amber-800">Agent proposes a fix (attempt {job.attempt}):</div>
          <div className="text-xs text-amber-900">{job.pending_fix.explanation}</div>
          <div className="mt-1 font-mono text-[11px] text-amber-700">edits: {(job.pending_fix.edits || []).join(", ")}</div>
          <div className="mt-2 flex gap-2">
            <button onClick={() => api.approve(job.id).then(reload)} className="rounded bg-emerald-600 px-3 py-1 text-xs font-medium text-white hover:bg-emerald-700">Approve & apply</button>
            <button onClick={() => api.reject(job.id).then(reload)} className="rounded bg-rose-600 px-3 py-1 text-xs font-medium text-white hover:bg-rose-700">Reject</button>
          </div>
        </div>
      )}

      {cols.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {job.stages.map(s => (
            <span key={s.name} className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-slate-600">
              <span className={`h-2.5 w-2.5 rounded ${CELL[s.status] || CELL.NOT_EXECUTED}`} />{s.name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Tab 2: Applications ───────────────────────────────────────────────────────
function Applications({ apps, reloadApps, cat }) {
  const [jobs, setJobs] = useState([]);
  const [selType, setSelType] = useState("");
  const [selVer, setSelVer] = useState("");
  const [result, setResult] = useState(null);
  const verList = (cat.versions && cat.versions[selType]) || [];
  const reloadJobs = useCallback(() => api.jobs().then(setJobs).catch(() => {}), []);
  useEffect(() => { reloadApps(); reloadJobs(); }, [reloadApps, reloadJobs]);

  // poll while any job active
  useEffect(() => {
    const active = jobs.some(j => !TERMINAL.includes(j.state));
    if (!active) return;
    const t = setInterval(reloadJobs, 4000);
    return () => clearInterval(t);
  }, [jobs, reloadJobs]);

  const jobsFor = id => jobs.filter(j => j.app_id === id).sort((a, b) => (b.id > a.id ? 1 : -1));

  if (!apps.length) return <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">No apps yet — register one first.</div>;

  return (
    <div className="grid gap-3">
      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <div className="flex flex-wrap items-end gap-3">
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-600">Type</span>
            <select className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500"
              value={selType} onChange={e => { setSelType(e.target.value); setSelVer(""); }}>
              <option value="">select…</option>
              {(cat.types || []).map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="mb-1 block text-xs font-medium text-slate-600">Version</span>
            <select className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500 disabled:bg-slate-50"
              value={selVer} onChange={e => setSelVer(e.target.value)} disabled={!selType}>
              <option value="">select…</option>
              {verList.map(v => <option key={v} value={v}>{selType} {v}</option>)}
            </select>
          </label>

          <button disabled={!selType || !selVer}
            onClick={() => api.bulkUpgrade(selType, selVer).then(r => { setResult(r); reloadJobs(); })}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50">
            <ArrowUpCircle size={15} /> Upgrade All
          </button>

          <button disabled={!selType}
            onClick={() => api.runAllByType(selType, selVer || null).then(r => { setResult(r); reloadJobs(); })}
            className="flex items-center gap-1.5 rounded-lg bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50">
            <PlayCircle size={15} /> Run All Pipelines
          </button>

          <button onClick={reloadJobs} className="ml-auto flex items-center gap-1 text-xs text-slate-500 hover:text-slate-700"><RefreshCw size={12} /> refresh</button>
        </div>
        <p className="mt-2 text-xs text-slate-400">
          <b>Upgrade All</b> upgrades only apps of that type not already on the selected version — the rest stay idle.
          <b className="ml-2">Run All Pipelines</b> triggers every Jenkins pipeline for that type with the base-image build args.
        </p>
        {result && (
          <div className="mt-3 rounded-lg bg-slate-50 p-3 text-xs">
            {result.upgrading && <div className="text-slate-700"><b>Upgrading:</b> {result.upgrading.map(x => x.name).join(", ") || "none"}</div>}
            {result.idle && <div className="text-slate-500"><b>Idle:</b> {result.idle.map(x => `${x.name} (${x.reason})`).join(", ") || "none"}</div>}
            {result.started && <div className="text-slate-700"><b>Triggered:</b> {(result.started.map ? result.started : []).join?.(", ") || JSON.stringify(result.started)}</div>}
          </div>
        )}
      </div>
      {apps.map(a => (
        <div key={a.id} className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="truncate text-sm font-semibold text-slate-800">{a.name}</span>
                <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${TYPE_CHIP[a.type] || TYPE_CHIP.unknown}`}>{a.type}</span>
              </div>
              <div className="font-mono text-xs text-slate-500">
                current: {a.current_version}
                {selType === a.type && selVer && (
                  _sameVer(a.current_version, selVer)
                    ? <span className="ml-2 text-emerald-600">idle — already on {selVer}</span>
                    : <span className="ml-2 text-indigo-600">will upgrade → {selType} {selVer}</span>
                )}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button onClick={() => api.trigger(a.id).then(reloadJobs)} className="flex items-center gap-1.5 rounded-lg bg-slate-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800"><PlayCircle size={14} /> Trigger Jenkins</button>
              <button onClick={() => api.rebuild(a.id).then(reloadJobs)} className="flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"><ShieldCheck size={14} /> Base-image rebuild</button>
              <button onClick={() => api.del(a.id).then(reloadApps)} className="text-xs text-rose-500 hover:underline">remove</button>
            </div>
          </div>
          {jobsFor(a.id).slice(0, 3).map(j => <JobCard key={j.id} job={j} reload={reloadJobs} />)}
        </div>
      ))}
    </div>
  );
}

// ── Shell ─────────────────────────────────────────────────────────────────────
const TABS = [{ k: "register", label: "Register", icon: Boxes }, { k: "apps", label: "Applications", icon: LayoutGrid }];

export default function AgenticPortal() {
  const [tab, setTab] = useState("apps");
  const [apps, setApps] = useState([]);
  const [cat, setCat] = useState({ types: [], versions: {} });
  const reloadApps = useCallback(() => api.apps().then(setApps).catch(() => {}), []);
  useEffect(() => { reloadApps(); api.catalog().then(setCat).catch(() => {}); }, [reloadApps]);

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-4xl items-center gap-3 px-4 py-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white"><Rocket size={20} /></div>
          <h1 className="text-base font-semibold text-slate-900">Application upgrade & rebuild agent</h1>
        </div>
        <div className="mx-auto flex max-w-4xl gap-1 px-4">
          {TABS.map(t => {
            const Icon = t.icon, on = tab === t.k;
            return <button key={t.k} onClick={() => { setTab(t.k); reloadApps(); }} className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium ${on ? "border-indigo-600 text-indigo-700" : "border-transparent text-slate-500 hover:text-slate-700"}`}><Icon size={16} /> {t.label}</button>;
          })}
        </div>
      </header>
      <main className="mx-auto max-w-4xl px-4 py-6">
        {tab === "register" && <Register types={cat.types || []} onDone={() => { reloadApps(); setTab("apps"); }} />}
        {tab === "apps" && <Applications apps={apps} reloadApps={reloadApps} cat={cat} />}
      </main>
    </div>
  );
}

"""The agentic upgrade flow (uses prompts.py for all model prompts).

  clone -> branch -> GPT-5.2 comprehensive upgrade edits (framework + packages +
        deprecated removal + code changes) -> build LOCALLY
        -> if build fails: GPT-5.2 proposes a fix -> PAUSE for user approval (semi-auto)
        -> on approve: apply + rebuild (capped) -> push -> trigger Jenkins -> poll
"""
from __future__ import annotations

import asyncio
import subprocess
import uuid
from pathlib import Path

import gitwork
import prompts
import runtimes
from jenkins_runner import jenkins
from llm import extract_json, llm

MAX_FIX_ATTEMPTS = 3

BUILD_CMDS = {
    ".NET": ["dotnet", "build"],
    "Node": ["npm", "run", "build"],
    "React": ["npm", "run", "build"],
    "Java": ["mvn", "-q", "-DskipTests", "package"],
}

# Verification step 2: tests. Compiling proves it builds; tests prove it still works.
TEST_CMDS = {
    ".NET": ["dotnet", "test", "--nologo"],
    "Node": ["npm", "test", "--if-present"],
    "React": ["npm", "test", "--if-present"],
    "Java": ["mvn", "-q", "test"],
}

# Source extensions gathered so the agent can modify code (focus: .NET + Node).
SOURCE_GLOBS = {
    ".NET": ["*.cs"],
    "Node": ["*.ts", "*.js", "*.tsx", "*.jsx"],
    "React": ["*.ts", "*.js", "*.tsx", "*.jsx"],
    "Java": ["*.java"],
}


def _build(repo: Path, kind: str) -> tuple[bool, str]:
    cmd = BUILD_CMDS.get(kind)
    if not cmd:
        return True, "no build command for this type (skipped)"
    if kind in ("Node", "React"):
        subprocess.run(["npm", "install"], cwd=str(repo), capture_output=True, text=True)
    p = subprocess.run(cmd, cwd=str(repo), capture_output=True, text=True)
    return p.returncode == 0, (p.stdout + "\n" + p.stderr)[-8000:]


def _test(repo: Path, kind: str) -> tuple[bool, str]:
    """Run the project's tests. Missing/zero tests are NOT treated as failure — we report it."""
    cmd = TEST_CMDS.get(kind)
    if not cmd:
        return True, "no test command for this type (skipped)"
    p = subprocess.run(cmd, cwd=str(repo), capture_output=True, text=True)
    log = (p.stdout + "\n" + p.stderr)[-8000:]
    return p.returncode == 0, log


def _manifests(repo: Path) -> str:
    blocks = []
    for pat in ["*.csproj", "package.json", "global.json", "Directory.Build.props", "pom.xml"]:
        for p in repo.rglob(pat):
            if ".git" not in p.parts:
                blocks.append(f"### {p.relative_to(repo)}\n{p.read_text(errors='ignore')[:4000]}")
    return "\n\n".join(blocks)


def _source_sample(repo: Path, kind: str, max_files: int = 12, per_file: int = 3000) -> str:
    blocks, n = [], 0
    for pat in SOURCE_GLOBS.get(kind, []):
        for p in repo.rglob(pat):
            if ".git" in p.parts or "node_modules" in p.parts or "obj" in p.parts or "bin" in p.parts:
                continue
            blocks.append(f"### {p.relative_to(repo)}\n{p.read_text(errors='ignore')[:per_file]}")
            n += 1
            if n >= max_files:
                return "\n\n".join(blocks)
    return "\n\n".join(blocks) if blocks else "(no source files gathered)"


async def _propose_edits(repo: Path, kind: str, target: str, images: dict | None = None) -> list[dict]:
    # Pull the exact target framework + image paths from the CENTRAL config so the agent
    # writes the same values everywhere (e.g. net11.0), not whatever it guesses.
    central = ""
    if images:
        central = ("\n\nUse these EXACT values (from the platform base-image registry). "
                   "Update the Dockerfile FROM lines to these images and set the target "
                   "framework accordingly:\n"
                   f"  base image (runtime stage): {images.get('base_image')}\n"
                   f"  build image (sdk stage):    {images.get('build_image')}\n"
                   f"  target framework:           {images.get('target_framework')}")
    reply = await llm.chat(
        prompts.UPGRADE_SYSTEM,
        prompts.upgrade_user(kind, target, _manifests(repo), _source_sample(repo, kind)) + central,
        max_completion_tokens=8000,
    )
    return extract_json(reply)


async def _propose_fix(repo: Path, kind: str, build_log: str) -> dict:
    files = "\n".join(gitwork.list_files(repo, 150))
    reply = await llm.chat(prompts.FIX_SYSTEM, prompts.fix_user(kind, build_log, files), max_completion_tokens=8000)
    return extract_json(reply)


def _apply(repo: Path, edits: list[dict]) -> None:
    for e in edits:
        if e.get("path") and "content" in e:
            gitwork.write_file(repo, e["path"], e["content"])


async def run_upgrade(job: dict, app: dict, approvals: dict[str, asyncio.Event]) -> None:
    kind = app["type"]
    target = job["target_version"]
    repo = None
    try:
        job["state"] = "cloning"
        repo = gitwork.clone(app["repo_url"], app["branch"])
        branch = f"upgrade/{target.replace(' ', '').lower()}-{uuid.uuid4().hex[:6]}"
        job["work_branch"] = branch
        gitwork.create_branch(repo, branch)

        job["state"] = "editing"                       # framework + packages + deprecated + code
        _apply(repo, await _propose_edits(repo, kind, target, app.get("images")))

        job["state"] = "building"
        ok, log = _build(repo, kind)
        if ok:
            job["state"] = "testing"
            ok, log = _test(repo, kind)
            job["tests_ran"] = True

        attempt = 0
        while not ok and attempt < MAX_FIX_ATTEMPTS:
            attempt += 1
            job["attempt"] = attempt
            proposal = await _propose_fix(repo, kind, log)
            job["pending_fix"] = {"explanation": proposal.get("explanation", ""),
                                  "edits": [e.get("path") for e in proposal.get("edits", [])]}
            job["state"] = "awaiting_approval"          # ── SEMI-AUTO GATE ──
            ev = approvals.setdefault(job["id"], asyncio.Event())
            ev.clear()
            await ev.wait()
            if job.get("approval") == "rejected":
                job["state"], job["error"] = "failed", "Fix rejected by user."
                return
            job["pending_fix"] = None
            _apply(repo, proposal.get("edits", []))
            job["state"] = "building"
            ok, log = _build(repo, kind)
            if ok:
                job["state"] = "testing"
                ok, log = _test(repo, kind)

        if not ok:
            job["state"], job["error"] = "failed", "Build/tests still failing after fix attempts."
            job["build_log_tail"] = log[-2000:]
            return

        job["verified"] = {"build": "passed", "tests": "passed"}
        job["state"] = "pushing"
        gitwork.commit_all(repo, f"Upgrade to {target}")
        gitwork.push(repo, branch)

        job["state"] = "jenkins_triggering"
        jparams = {"BRANCH": branch, "TARGET": target}
        if app.get("images"):
            jparams.update({"BASE_IMAGE": app["images"].get("base_image", ""),
                            "BUILD_IMAGE": app["images"].get("build_image", "")})
        job["queue_url"] = await jenkins.trigger(app["jenkins_job"], jparams)
        job["state"] = "jenkins_running"
        await _poll_jenkins(job, app["jenkins_job"])
    except Exception as e:  # noqa: BLE001
        job["state"], job["error"] = "failed", str(e)
    finally:
        if repo:
            gitwork.cleanup(repo)


async def _poll_jenkins(job: dict, jenkins_job: str) -> None:
    for _ in range(120):
        if job.get("build_no") is None:
            job["build_no"] = await jenkins.resolve_build(job.get("queue_url", ""))
        if job.get("build_no") is not None:
            s = await jenkins.stages(jenkins_job, job["build_no"])
            job["jenkins_status"], job["stages"] = s["status"], s["stages"]
            if s["status"] in ("SUCCESS", "FAILED", "ABORTED", "UNSTABLE"):
                job["state"] = "completed" if s["status"] == "SUCCESS" else "jenkins_failed"
                return
        await asyncio.sleep(5)
    job["state"] = "timeout"

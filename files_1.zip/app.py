"""Agentic upgrade + base-image rebuild backend (Azure OpenAI GPT-5.2 + Jenkins).

Tab 1  register app -> clone -> analyze (type/current/available version) -> save JSON
Tab 2  list apps -> Upgrade (agent) OR trigger Jenkins; base-image rebuild from EKS tag
        live status; semi-auto approval of agent fixes before push
"""
from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from typing import Optional

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import base_images
import catalog
import detect
import runtimes
import versions
import eks
import gitwork
from agent import run_upgrade
from jenkins_runner import jenkins
from settings import settings

# ── Models ────────────────────────────────────────────────────────────────────
class AppIn(BaseModel):
    name: str
    type: str                            # selected in the UI: .NET | React | Java
    repo_url: str
    branch: str = "main"
    jenkins_job: str                     # Jenkins pipeline (job name)
    config_repo_url: str = ""            # repo with EKS details
    cluster: str = ""                    # EKS QA cluster name
    namespace: str = ""
    deployment: str = ""
    app_prefix: str = ""                 # image-tag prefix to strip when deriving git tag


class App(AppIn):
    id: str
    current_version: str = "unknown"      # detected by the agent (current only)
    analyze_error: Optional[str] = None
    files_inspected: list[str] = []


APPS_FILE = Path("apps.json")
APPS: dict[str, App] = {}
JOBS: dict[str, dict] = {}                     # upgrade + rebuild jobs (in-memory)
APPROVALS: dict[str, asyncio.Event] = {}


def _save():
    try:
        APPS_FILE.write_text(json.dumps([a.model_dump() for a in APPS.values()], indent=2))
    except Exception:
        pass


def _load():
    if APPS_FILE.exists():
        try:
            for d in json.loads(APPS_FILE.read_text()):
                APPS[d["id"]] = App(**d)
        except Exception:
            pass


_load()

app = FastAPI(title="Agentic Upgrade + Rebuild (GPT-5.2 + Jenkins)")
app.add_middleware(CORSMiddleware, allow_origins=[settings.frontend_origin, "http://localhost:3000"],
                   allow_methods=["*"], allow_headers=["*"])


# ── Tab 1: register + analyze ─────────────────────────────────────────────────
def _norm_repo(url: str) -> str:
    return url.strip().rstrip("/").removesuffix(".git").lower()


@app.post("/api/apps", response_model=App)
async def register(body: AppIn) -> App:
    # 2. no duplicates — verified by GitHub URL
    incoming = _norm_repo(body.repo_url)
    for existing in APPS.values():
        if _norm_repo(existing.repo_url) == incoming:
            raise HTTPException(409, f"Already registered as '{existing.name}' (same repository URL).")

    rec = App(id=str(uuid.uuid4()), **body.model_dump())
    repo = None
    try:
        repo = gitwork.clone(rec.repo_url, rec.branch)
        info = await detect.analyze(repo, rec.type)     # 3. current version only
        rec.current_version = info["current_version"]
        rec.files_inspected = info.get("files_inspected", [])
    except Exception as e:  # noqa: BLE001
        rec.analyze_error = str(e)
    finally:
        if repo:
            gitwork.cleanup(repo)
    APPS[rec.id] = rec
    _save()
    return rec


@app.post("/api/apps/{app_id}/reanalyze", response_model=App)
async def reanalyze(app_id: str) -> App:
    rec = APPS.get(app_id)
    if not rec:
        raise HTTPException(404, "Unknown app")
    return await register(AppIn(**{k: getattr(rec, k) for k in AppIn.model_fields}))


@app.get("/api/apps", response_model=list[App])
def list_apps() -> list[App]:
    return list(APPS.values())


@app.delete("/api/apps/{app_id}")
def delete_app(app_id: str) -> dict:
    if APPS.pop(app_id, None) is None:
        raise HTTPException(404, "Unknown app")
    _save()
    return {"deleted": app_id}


# ── Tab 2a: version upgrade (agentic) ─────────────────────────────────────────
class UpgradeIn(BaseModel):
    app_id: str
    target_version: Optional[str] = None   # defaults to app.upgrade_available


@app.post("/api/upgrades")
async def start_upgrade(body: UpgradeIn, bg: BackgroundTasks) -> dict:
    a = APPS.get(body.app_id)
    if not a:
        raise HTTPException(404, "Unknown app")
    target = body.target_version or a.upgrade_available
    if not target:
        raise HTTPException(400, "No upgrade target (app is up to date or version unknown).")
    job = {"id": str(uuid.uuid4()), "kind": "upgrade", "app_id": a.id, "app_name": a.name,
           "target_version": target, "state": "queued", "stages": [], "build_no": None}
    JOBS[job["id"]] = job
    bg.add_task(_run_upgrade_task, job, a.model_dump())
    return job


async def _run_upgrade_task(job: dict, app_dict: dict):
    await run_upgrade(job, app_dict, APPROVALS)


@app.post("/api/upgrades/{job_id}/approve")
def approve(job_id: str) -> dict:
    return _resolve_approval(job_id, "approved")


@app.post("/api/upgrades/{job_id}/reject")
def reject(job_id: str) -> dict:
    return _resolve_approval(job_id, "rejected")


def _resolve_approval(job_id: str, decision: str) -> dict:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Unknown job")
    if job.get("state") != "awaiting_approval":
        raise HTTPException(400, "Job is not awaiting approval")
    job["approval"] = decision
    APPROVALS.setdefault(job_id, asyncio.Event()).set()
    return {"job_id": job_id, "decision": decision}


# ── Tab 2b: base-image rebuild (EKS tag -> branch -> Jenkins) ──────────────────
@app.post("/api/rebuilds/all")
async def rebuild_all(bg: BackgroundTasks, runtime: Optional[str] = None,
                      app_type: Optional[str] = None) -> dict:
    """Base-image rebuild across apps. Filter so you only run what infra actually fixed:
       ?runtime=dotnet   -> only .NET apps
       ?runtime=node     -> only Node/React apps
       (no filter)       -> every registered app"""
    started, skipped = [], []
    for a in APPS.values():
        if runtime and a.runtime != runtime:
            skipped.append(a.name); continue
        if app_type and a.type != app_type:
            skipped.append(a.name); continue
        if not (a.cluster and a.namespace and a.deployment):
            skipped.append(a.name); continue
        job = {"id": str(uuid.uuid4()), "kind": "rebuild", "app_id": a.id, "app_name": a.name,
               "state": "queued", "stages": [], "build_no": None}
        JOBS[job["id"]] = job
        bg.add_task(_run_rebuild_task, job, a.model_dump())
        started.append(job["id"])
    return {"started": started, "count": len(started), "skipped": skipped, "runtime": runtime}


@app.post("/api/rebuilds")
async def start_rebuild(body: UpgradeIn, bg: BackgroundTasks) -> dict:
    a = APPS.get(body.app_id)
    if not a:
        raise HTTPException(404, "Unknown app")
    if not (a.cluster and a.namespace and a.deployment):
        raise HTTPException(400, "App is missing EKS cluster/namespace/deployment (config repo details).")
    job = {"id": str(uuid.uuid4()), "kind": "rebuild", "app_id": a.id, "app_name": a.name,
           "state": "queued", "stages": [], "build_no": None}
    JOBS[job["id"]] = job
    bg.add_task(_run_rebuild_task, job, a.model_dump())
    return job


async def _run_rebuild_task(job: dict, a: dict):
    try:
        job["state"] = "reading_eks"
        eks.octo_login()
        image = eks.get_running_image(a["cluster"], a["namespace"], a["deployment"])
        job["running_image"] = image
        git_tag = eks.derive_git_tag(image, a["app_prefix"])
        job["git_tag"] = git_tag

        job["state"] = "branching"
        repo = gitwork.clone(a["repo_url"], git_tag)   # clone at the tag
        repo_name = a["repo_url"].rstrip("/").split("/")[-1].removesuffix(".git")
        branch = f"bmi_{repo_name}_{uuid.uuid4().hex[:8]}"
        job["work_branch"] = branch
        gitwork.create_branch(repo, branch)
        gitwork.commit_all(repo, f"Base-image rebuild from {git_tag}")   # marker commit
        gitwork.push(repo, branch)
        gitwork.cleanup(repo)

        job["state"] = "jenkins_triggering"
        params = {"BRANCH": branch, "GIT_TAG": git_tag}
        # Central runtime config supplies the image version + paths as build-args, so a
        # version bump is ONE edit in runtimes.json — not one Dockerfile edit per repo.
        rt = a.get("runtime")
        if rt:
            params.update(runtimes.build_args(rt))
        queue = await jenkins.trigger(a["jenkins_job"], params)
        job["queue_url"] = queue
        job["state"] = "jenkins_running"
        await _poll(job, a["jenkins_job"])
    except Exception as e:  # noqa: BLE001
        job["state"] = "failed"
        job["error"] = str(e)


async def _poll(job: dict, jenkins_job: str):
    for _ in range(120):
        if job.get("build_no") is None:
            job["build_no"] = await jenkins.resolve_build(job.get("queue_url", ""))
        if job.get("build_no") is not None:
            s = await jenkins.stages(jenkins_job, job["build_no"])
            job["jenkins_status"] = s["status"]
            job["stages"] = s["stages"]
            if s["status"] in ("SUCCESS", "FAILED", "ABORTED", "UNSTABLE"):
                job["state"] = "completed" if s["status"] == "SUCCESS" else "jenkins_failed"
                return
        await asyncio.sleep(5)
    job["state"] = "timeout"


# ── Plain Jenkins trigger (for "up to date" apps) ─────────────────────────────
@app.post("/api/jenkins/trigger")
async def trigger_jenkins(body: UpgradeIn, bg: BackgroundTasks) -> dict:
    a = APPS.get(body.app_id)
    if not a:
        raise HTTPException(404, "Unknown app")
    job = {"id": str(uuid.uuid4()), "kind": "trigger", "app_id": a.id, "app_name": a.name,
           "state": "jenkins_triggering", "stages": [], "build_no": None}
    JOBS[job["id"]] = job

    async def _t():
        try:
            job["queue_url"] = await jenkins.trigger(a.jenkins_job, {"BRANCH": a.branch})
            job["state"] = "jenkins_running"
            await _poll(job, a.jenkins_job)
        except Exception as e:  # noqa: BLE001
            job["state"] = "failed"
            job["error"] = str(e)

    bg.add_task(_t)
    return job


# ── Static dropdowns: Type + Version (from base_images.json) ───────────────────
@app.get("/api/catalog")
def get_catalog() -> dict:
    """Type dropdown + the versions available for each type, with their base images."""
    reg = catalog.load()
    return {"types": catalog.types(),
            "versions": {t: catalog.versions(t) for t in catalog.types()},
            "images": reg}


# ── Bulk upgrade: only apps NOT already on the selected version ────────────────
class BulkUpgradeIn(BaseModel):
    type: str                 # ".NET"
    target_version: str       # "10"


@app.post("/api/upgrades/bulk")
async def bulk_upgrade(body: BulkUpgradeIn, bg: BackgroundTasks) -> dict:
    """Select type + version, hit Upgrade All.
       Apps of that type NOT on the target version are upgraded; everything else is idle."""
    imgs = catalog.image_set(body.type, body.target_version)
    if not imgs:
        raise HTTPException(400, f"No base image configured for {body.type} {body.target_version}.")

    started, idle = [], []
    for a in APPS.values():
        if a.type != body.type:
            idle.append({"name": a.name, "reason": "different type"})
            continue
        if _same_version(a.current_version, body.target_version):
            idle.append({"name": a.name, "reason": f"already on {body.target_version}"})
            continue
        job = {"id": str(uuid.uuid4()), "kind": "upgrade", "app_id": a.id, "app_name": a.name,
               "target_version": f"{body.type} {body.target_version}", "state": "queued",
               "stages": [], "build_no": None, "images": imgs}
        JOBS[job["id"]] = job
        bg.add_task(_run_upgrade_task, job, {**a.model_dump(), "images": imgs,
                                             "target_version_num": body.target_version})
        started.append({"name": a.name, "job_id": job["id"]})
    return {"type": body.type, "target_version": body.target_version,
            "upgrading": started, "idle": idle}


def _same_version(current: str | None, target: str) -> bool:
    """'.NET 10' / 'net10.0' / '10.0' all match target '10'."""
    if not current:
        return False
    import re as _re
    nums = _re.findall(r"\d+(?:\.\d+)?", str(current))
    t = str(target).split(".")[0]
    return any(n.split(".")[0] == t for n in nums)


# ── Run all Jenkins pipelines for a type (with image upgrade) ──────────────────
class BulkRunIn(BaseModel):
    type: str
    target_version: Optional[str] = None


@app.post("/api/jenkins/run-all")
async def run_all_by_type(body: BulkRunIn, bg: BackgroundTasks) -> dict:
    """Type = .NET + Run All -> triggers every .NET Jenkins pipeline, passing the base
       image build-args so the rebuild picks up the upgraded image."""
    params_base = catalog.build_args(body.type, body.target_version) if body.target_version else {}
    started, skipped = [], []
    for a in APPS.values():
        if a.type != body.type:
            skipped.append(a.name)
            continue
        job = {"id": str(uuid.uuid4()), "kind": "run", "app_id": a.id, "app_name": a.name,
               "state": "jenkins_triggering", "stages": [], "build_no": None}
        JOBS[job["id"]] = job
        bg.add_task(_run_pipeline_task, job, a.model_dump(), dict(params_base))
        started.append(a.name)
    return {"type": body.type, "target_version": body.target_version,
            "started": started, "skipped": skipped, "build_args": params_base}


async def _run_pipeline_task(job: dict, a: dict, extra_params: dict):
    try:
        params = {"BRANCH": a.get("branch", "main"), **extra_params}
        job["queue_url"] = await jenkins.trigger(a["jenkins_job"], params)
        job["state"] = "jenkins_running"
        await _poll(job, a["jenkins_job"])
    except Exception as e:  # noqa: BLE001
        job["state"], job["error"] = "failed", str(e)


# ── Central runtime config (THE place you change for a new version) ────────────
@app.get("/api/runtimes")
def get_runtimes() -> dict:
    """Current version + resolved ECR image paths per runtime."""
    cfg = runtimes.load()
    return {rt: {**cfg[rt], **runtimes.images(rt)} for rt in cfg}


class RuntimeVersionIn(BaseModel):
    version: str


@app.put("/api/runtimes/{runtime}/version")
def set_runtime_version(runtime: str, body: RuntimeVersionIn) -> dict:
    """Bump the central version — e.g. .NET 11 lands, set it once here.
    Image paths and the .csproj target framework derive from it automatically."""
    updated = runtimes.set_version(runtime, body.version)
    return {"runtime": runtime, **updated, **runtimes.images(runtime),
            "target_framework": runtimes.target_framework(runtime)}


# ── Version availability (upstream AND buildable) ──────────────────────────────
@app.get("/api/apps/{app_id}/upgrade-check")
async def upgrade_check(app_id: str) -> dict:
    """Is a newer version really available for this app?
       upstream  = official release feed (authoritative) / catalog / LLM
       buildable = base image for that version exists in our ECR
       An upgrade is offered only when BOTH agree."""
    a = APPS.get(app_id)
    if not a:
        raise HTTPException(404, "Unknown app")
    runtime = a.runtime or base_images.RUNTIME_OF_TYPE.get(a.type, "")
    ups, source = await versions.upstream_versions(runtime)
    candidates = versions.newer_than(ups, a.base_version)

    buildable, probe_source = [], settings.base_image_strategy
    if candidates:
        if settings.base_image_strategy == "catalog":
            have = set(base_images.available_versions(runtime))
            buildable = [v for v in candidates if v in have]
        else:
            try:
                res = await base_images.probe_via_jenkins(runtime, candidates[:5])
                buildable = res.get("exists", [])
            except Exception as e:  # noqa: BLE001
                probe_source = f"probe failed: {e}"

    return {
        "app": a.name, "runtime": runtime, "current_base_version": a.base_version,
        "upstream_versions": candidates, "upstream_source": source,
        "buildable_versions": buildable, "base_image_source": probe_source,
        "recommended": buildable[0] if buildable else None,
        "note": "Upgrade is offered only when the version exists upstream AND its base image is in ECR.",
    }


# ── Base images ────────────────────────────────────────────────────────────────
@app.get("/api/base-images/{runtime}")
async def base_image_versions(runtime: str, candidates: str = "") -> dict:
    """Which base-image versions exist in ECR for this runtime.
    strategy=catalog       -> read the infra-published JSON
    strategy=jenkins_probe -> ask Jenkins (its agents already have ECR access)
    """
    if settings.base_image_strategy == "catalog":
        return {"runtime": runtime, "available": base_images.available_versions(runtime),
                "source": "catalog"}
    cand = [c.strip() for c in candidates.split(",") if c.strip()]
    if not cand:
        raise HTTPException(400, "Pass ?candidates=11.0,10.0 to probe.")
    res = await base_images.probe_via_jenkins(runtime, cand)
    return {"runtime": runtime, "source": "jenkins_probe", **res}


class BaseBumpIn(BaseModel):
    app_id: str
    new_version: str          # e.g. "11.0"


@app.post("/api/base-images/bump")
def bump_base_version(body: BaseBumpIn) -> dict:
    """Record the intended base-image version. The rebuild job passes it to Jenkins as a
    build-arg, and the Dockerfile ARG makes it a one-line change."""
    a = APPS.get(body.app_id)
    if not a:
        raise HTTPException(404, "Unknown app")
    a.base_version = body.new_version
    _save()
    return {"app": a.name, "base_version": a.base_version}


# ── Status ────────────────────────────────────────────────────────────────────
@app.get("/api/jobs")
def list_jobs() -> list[dict]:
    return list(JOBS.values())


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str) -> dict:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Unknown job")
    return job


@app.get("/health")
def health() -> dict:
    return {"ok": True,
            "openai_configured": bool(settings.openai_url and settings.openai_key),
            "github_configured": bool(settings.github_pat),
            "jenkins_configured": bool(settings.jenkins_token)}

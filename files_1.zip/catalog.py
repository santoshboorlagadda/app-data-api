"""Static Type/Version catalog + the base-image registry.

base_images.json is the ONE place you maintain:
    type -> version -> { base_image, build_image, target_framework }

Add a version there and it appears in the UI dropdowns automatically. The agent is given
the exact base_image/build_image/target_framework for the selected target so the PR it
raises uses your real ECR paths, not something it invented.
"""
from __future__ import annotations

import json
from pathlib import Path

REGISTRY = Path("base_images.json")


def load() -> dict:
    if not REGISTRY.exists():
        return {}
    try:
        data = json.loads(REGISTRY.read_text())
        return {k: v for k, v in data.items() if not k.startswith("_")}
    except Exception:
        return {}


def types() -> list[str]:
    """Dropdown 1: .NET, React, Java ..."""
    return list(load().keys())


def versions(app_type: str) -> list[str]:
    """Dropdown 2: versions available for that type, newest first."""
    v = list(load().get(app_type, {}).keys())
    return sorted(v, key=lambda x: float(x) if x.replace(".", "").isdigit() else 0, reverse=True)


def image_set(app_type: str, version: str) -> dict:
    """The exact images + target framework the agent must use."""
    return load().get(app_type, {}).get(str(version), {})


def build_args(app_type: str, version: str) -> dict:
    """Params passed to Jenkins so the pipeline builds with the right base image."""
    s = image_set(app_type, version)
    if not s:
        return {}
    return {
        "BASE_IMAGE": s.get("base_image", ""),
        "BUILD_IMAGE": s.get("build_image", ""),
        "TARGET_VERSION": str(version),
    }

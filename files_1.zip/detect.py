"""Repo analysis — fully agent-driven, two passes, no hardcoded file patterns.

  Pass 1: the agent sees ONLY the file listing and replies with which files it wants to read.
  Pass 2: we send exactly those files back; the agent decides type + current version.

Nothing here decides "csproj means .NET". The agent does. If the model is unreachable we
return "unknown" rather than guessing with hardcoded rules.
"""
from __future__ import annotations

from pathlib import Path

import prompts
from gitwork import list_files
from llm import extract_json, llm

MAX_PICKED_FILES = 12
MAX_BYTES_PER_FILE = 6000


def _read(repo: Path, rel: str) -> str | None:
    try:
        p = (repo / rel).resolve()
        if repo.resolve() not in p.parents and p != repo.resolve():
            return None                      # stay inside the repo
        if not p.is_file():
            return None
        return p.read_text(errors="ignore")[:MAX_BYTES_PER_FILE]
    except Exception:
        return None


async def analyze(repo: Path, app_type: str = "") -> dict:
    listing = "\n".join(list_files(repo, 400))

    # ── Pass 1: agent chooses which files it needs ──
    picked: list[str] = []
    try:
        reply = await llm.chat(prompts.PICK_FILES_SYSTEM, prompts.pick_files_user(listing), max_completion_tokens=400)
        picked = [str(x) for x in extract_json(reply)][:MAX_PICKED_FILES]
    except Exception:
        picked = []

    # ── Pass 2: agent decides from the contents it asked for ──
    blocks = []
    for rel in picked:
        content = _read(repo, rel)
        if content is not None:
            blocks.append(f"### {rel}\n{content}")
    contents = "\n\n".join(blocks) if blocks else "(agent selected no readable files)"

    try:
        reply = await llm.chat(prompts.DETECT_SYSTEM,
                               prompts.detect_user(listing, contents, app_type),
                               max_completion_tokens=300)
        d = extract_json(reply)
        return {"current_version": d.get("current_version") or "unknown",
                "files_inspected": picked}
    except Exception as e:  # noqa: BLE001
        # No hardcoded guessing. If the agent can't answer, say so.
        return {"current_version": "unknown", "files_inspected": picked,
                "detect_error": f"agent detection failed: {e}"}

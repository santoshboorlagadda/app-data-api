"""Thin client for your internal Azure OpenAI (GPT-5.2) APIM endpoint."""
from __future__ import annotations

import json
import re

import httpx

from settings import settings


class LLM:
    def __init__(self) -> None:
        self._url = settings.openai_url
        self._headers = {
            "Content-Type": "application/json",
            settings.openai_key_header: settings.openai_key,
        }

    async def chat(self, system: str, user: str, temperature: float = 0.0, max_completion_tokens: int = 4000) -> str:
        if not self._url or not settings.openai_key:
            raise RuntimeError("OPENAI_URL / OPENAI_KEY not configured in .env")
        body = {
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_completion_tokens": max_completion_tokens,
        }
        async with httpx.AsyncClient(timeout=180) as c:
            r = await c.post(self._url, headers=self._headers, json=body)
        if r.status_code >= 300:
            raise RuntimeError(f"LLM call failed: {r.status_code} {r.text[:400]}")
        return r.json()["choices"][0]["message"]["content"]


def extract_json(text: str):
    """Pull the first JSON object/array out of a model reply (handles ``` fences)."""
    t = text.strip()
    t = re.sub(r"^```[a-zA-Z]*", "", t).strip().strip("`").strip()
    m = re.search(r"(\{.*\}|\[.*\])", t, re.DOTALL)
    if not m:
        raise ValueError("No JSON found in model reply.")
    return json.loads(m.group(1))


llm = LLM()

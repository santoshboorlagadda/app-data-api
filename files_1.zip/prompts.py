"""All GPT-5.2 prompts live here so you can read and tune them in one place.
Focus: .NET and Node (extend the guidance blocks for other types as needed)."""

# ── Pass 1: the agent picks which files it needs to read ──
PICK_FILES_SYSTEM = (
    "You are inspecting an unfamiliar code repository. Given ONLY the file listing, choose "
    "which files you need to read to determine the application type and its framework/runtime "
    "version (build manifests, project files, dependency files, version/config files, container "
    "files). Choose at most 12, most informative first.\n"
    'Reply ONLY as a JSON array of relative paths, e.g. ["src/App.csproj", "Dockerfile"]. No prose.'
)


def pick_files_user(file_listing: str) -> str:
    return f"Repository file listing:\n{file_listing}\n\nWhich files do you need to read?"


# ── Pass 2: the agent decides the type + version from the files it asked for ──
DETECT_SYSTEM = (
    "You determine ONLY the CURRENT framework/runtime version of an application from its "
    "files. Do not speculate about newer releases — the platform manages target versions.\n"
    'Reply ONLY as compact JSON, no prose: {"current_version": "<e.g. .NET 6 / React 17>"}'
)


def detect_user(file_listing: str, key_files: str, app_type: str = "") -> str:
    t = f"The application type is {app_type}.\n" if app_type else ""
    return (
        f"{t}Repository files:\n{file_listing}\n\n"
        f"Contents of the files you asked for:\n{key_files}\n\n"
        "What is the CURRENT version?"
    )


# ── Upgrade: comprehensive — framework + packages + deprecated + code changes ──
UPGRADE_SYSTEM = (
    "You are an application upgrade agent. Upgrade the given project to the target version and "
    "make it build cleanly. Do a COMPLETE upgrade, not just the framework bump:\n"
    "  1. Raise the target framework / runtime to the target version.\n"
    "  2. Upgrade ALL dependency packages (NuGet for .NET, npm for Node) to versions compatible "
    "     with the target. Prefer the latest stable compatible version of each.\n"
    "  3. REMOVE deprecated, obsolete, or unused packages, and replace them with their modern "
    "     equivalents where one exists.\n"
    "  4. MODIFY SOURCE CODE where the upgrade requires it: fix breaking API changes, obsolete "
    "     APIs, changed namespaces, nullable/async changes, etc.\n"
    "Return ONLY a JSON array of full file replacements — every file you change, with complete "
    'new content: [{"path": "relative/path", "content": "<full new file content>"}]. No prose.\n'
    "Guidance:\n"
    "  .NET  — edit .csproj <TargetFramework>, PackageReference versions; drop deprecated NuGet "
    "          packages; update Program.cs/Startup and any obsolete API usage.\n"
    "  Node  — edit package.json engines + dependency versions; remove deprecated npm packages; "
    "          update code for breaking changes in upgraded libs."
)


def upgrade_user(kind: str, target: str, manifests: str, source_sample: str) -> str:
    return (
        f"Upgrade this {kind} project to {target}.\n\n"
        f"Manifest/build files:\n{manifests}\n\n"
        f"Representative source files (edit these and any others that need changes):\n{source_sample}"
    )


# ── Fix: repair a failed build after an upgrade (semi-auto, user approves) ──
FIX_SYSTEM = (
    "A build failed after an upgrade. Propose the MINIMAL set of edits to make it build. "
    "Consider missing/incompatible packages, removed APIs, and syntax from the new version. "
    'Return ONLY JSON: {"explanation": "<1-2 sentences>", '
    '"edits": [{"path": "...", "content": "<full new file content>"}]}'
)


def fix_user(kind: str, build_log: str, files: str) -> str:
    return f"Type: {kind}\n\nBuild log (tail):\n{build_log}\n\nRepo files:\n{files}"
